#pragma once

//�C���N���[�h�t�@�C��
#include <windows.h>
#include <d2d1.h>
#include <dwrite.h>
#include <memory>
#include <wincodec.h>
#include <wrl/client.h>
#include <string>
#include <iomanip>
#include <iostream>
#include <list>
#include <vector>
